Magic Maze: A maze-based puzzle game made by Tristan Pritchett, Vivianne Purvis, 
and Everett Yan for FBLA's Computer Game and Simulation Programming event.

Magic Maze is a maze game with a twist. Not only can you break the maze's walls, you have to!
Each level is designed to be impossible without the player clicking on the maze's walls to
break them. Along the way, pickups can be collected, and there are enemies to avoid.

To launch the game, click on MagicMaze.exe. It is in the same directory as this .txt file.
Do not worry if your anti-virus program initially stops Magic Maze from launching. Anti-viruses
are sensitive about launching stand-alone .exe files. Within a few seconds, your anti-virus
should clear the game.
Further gameplay instructions lie in the game itself. 

The game was developed using the Godot engine and included editor. The only other
technology used was SilentWolf's leaderboard backend. This backend allows for an
online-capable leaderboard. Any individual with a copy of MagicMaze.exe can
submit their own scores, and they will appear on others' leaderboards. The
leaderboard can be reset, and may be reset periodically. This game also utilizes
royalty-free music courtesy of Eric Maytas and royalty-free sound effects thanks to
Mixkit.